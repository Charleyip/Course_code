Instructions:

For our assignment, the questions are in .ipynb files and you need to write your code in .py files.

In .py files you will see code blocks that look like this:

##############################################################################
#                    TODO: Write the equation for a line                     #
##############################################################################
pass
##############################################################################
#                              END OF YOUR CODE                              #
##############################################################################

You should replace the `pass` statement with your own code and leave the blocks intact, like this:

##############################################################################
#                    TODO: Write the equation for a line                     #
##############################################################################
y = m * x + b
##############################################################################
#                              END OF YOUR CODE                              #
##############################################################################

When completing the notebook, please adhere to the following rules:
- Do not write or modify any code outside of code blocks
- Do not add or delete any cells from the notebook. You may add new cells to perform scatch work, but delete them before submitting.
- Run all cells before submitting. You will only get credit for code that has been run!

The last point is extremely important and bears repeating:

We will not re-run your notebook -- you will only get credit for cells that have been run.