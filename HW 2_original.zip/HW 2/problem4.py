import torch
from torch import nn

class LeNet(nn.Module):
    def __init__(self):
        super().__init__()
        ###################################################################
        # TODO: Design your own network, define layers here.              #
        # Some common Choices are: Linear, Conv2d, ReLU, MaxPool2d        #
        ###################################################################
        # Replace "pass" statement with your code
        pass
        ###################################################################
        #                     END OF YOUR CODE                            #
        ###################################################################

    def forward(self,x):
        ###################################################################
        # TODO: Design your own network, implement forward pass here.     #
        ###################################################################
        # Replace "pass" statement with your code
        pass
        ###################################################################
        #                     END OF YOUR CODE                            #
        ###################################################################
        return x